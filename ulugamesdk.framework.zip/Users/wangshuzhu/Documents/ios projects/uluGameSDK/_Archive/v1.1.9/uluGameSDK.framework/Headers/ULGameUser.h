//
//  ULGameUser.h
//  ULUKit
//
//  Created by Wangshu Zhu on 2019/1/28.
//  Copyright © 2019 ulugame. All rights reserved.
//

#import <Foundation/Foundation.h>


NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, ULGameUserType) {
    ULGameUserTypeFacebook = 3,
    ULGameUserTypeGameCenter = 6,
    ULGameUserTypeGuest = 1,
    ULGameUserTypeGoogle = 4,
    ULGameUserTypeULGame = 2,
    ULGameUserTypeTwitter = 5
};

typedef NS_ENUM(unsigned int, ULGameBindInfo) {
    ULFacebookBind = 1u << 1,
    ULTwitterBind  = 1u << 2,
    ULGameCenterBind = 1u << 3,
    ULGoogleBind = 1u << 4,
    ULUlugamesBind = 1u << 5
};

@interface ULGameUser : NSObject <NSSecureCoding>

@property (nonatomic, strong, readonly) NSString *uid; //第三方uid
@property (nonatomic, strong, readonly) NSString *deviceId; //设备id
@property (nonatomic, strong, readonly) NSString *token; //用户密码
@property (nonatomic, strong, readonly) NSString *originGuestUid; // 游陆用户ID
@property (nonatomic, strong, readonly) NSString *userType;  //保存用户的类型信息： Facebook，GameCenter， ulugame user
@property (nonatomic, strong, readonly) NSString *nickname; //用户名
@property (nonatomic, strong, readonly) NSString *avatar; // 用户头像地址
@property (nonatomic, strong, readonly) NSString *lastLogin; //上次登陆时间
@property (nonatomic, strong, readonly) NSString *bindInfo; //绑定信息

- (instancetype)initWithUID:(NSString *)uid deviceID:(NSString *)deviceID token:(NSString *)userToken loginTime:(NSString *)loginTime;

@end

NS_ASSUME_NONNULL_END
