//
//  uluGameSDK.h
//  uluGameSDK
//
//  Created by Wangshu Zhu on 2019/1/29.
//  Copyright © 2019 ulugame. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for uluGameSDK.
FOUNDATION_EXPORT double uluGameSDKVersionNumber;

//! Project version string for uluGameSDK.
FOUNDATION_EXPORT const unsigned char uluGameSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <uluGameSDK/PublicHeader.h>

#import <uluGameSDK/ULGameUser.h>
#import <uluGameSDK/ULManager.h>

