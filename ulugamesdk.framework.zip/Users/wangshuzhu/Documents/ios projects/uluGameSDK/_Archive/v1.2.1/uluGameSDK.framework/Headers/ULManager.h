//
//  ULManager.h
//  ULUKit
//
//  Created by Wangshu Zhu on 2019/1/23.
//  Copyright © 2019 ulugame. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

//自定义头文件     
#import "ULGameUser.h"

NS_ASSUME_NONNULL_BEGIN


#pragma mark 类型定义


/**
 错误码

 - UL_CODE_SUCCESS: 登录成功
 - UL_CODE_FAIL: 登录失败
 - UL_CODE_INTERNAL_ERROR: 内部错误
 - UL_CODE_NETWORK_TIMEOUT: 超时
 - UL_CODE_SERVER_REJECTED: 服务器拒绝
 */
typedef NS_ENUM(NSUInteger, ULCode) {
    
    UL_CODE_SUCCESS = 0,
    UL_CODE_FAIL,
    UL_CODE_INTERNAL_ERROR,
    UL_CODE_NETWORK_TIMEOUT,
    UL_CODE_SERVER_REJECTED
};


// 设置角色信息 setRoleInfo接口 关键字定义
#define kULCustomerVipLevel @"ulvipLevel"
#define kULRoleName @"ulplayerName"
#define kULServerName @"ulserverName"
#define KULPlayerLevel @"ulroleLevel"
#define kULGameVersionNumber @"ulgameVersion"
#define kULServerId @"ulserverId"
#define kULRoleId @"ulroleid"

/**
 登录结果回调

 @param code 错误码
 @param userInfo 用户信息
 */
typedef void (^completionBlock)(ULCode code,NSDictionary *userInfo);



/**
 ULManager类的代理协议，实现这个协议来接受各种用户操作的回调
 */
@protocol ULManagerDelegate <NSObject>

@required

NS_ASSUME_NONNULL_END
/**
 用户登录回调，返回用户信息和错误码

 @param user 登录成功的话里面包含用户信息，否则为nil
 @param code 登录成功为nil，否则包含错误码
 */
- (void) userDidLogin:(ULGameUser * __nullable)user errorCode:(ULCode)code;

NS_ASSUME_NONNULL_BEGIN
/**
 用户登出回调

 @param uid 登出用户的uid
 */
- (void) userDidLogout:(NSString *)uid;



@optional


/**
 支付成功的回调

 @param code 返回的错误码
 */
- (void)paymentDidCompleteWithCode:(ULCode)code product:(NSString *)productIdentifier andQuantity:(NSInteger)quantity;



/**
 接受App Store发起的支付订单，创建订单后通过callback函数返回给SDK(非主线程调用)
 
 注意此时创建的订单后续不要再调用makepayment方法否则会造成重复下单。
 如果callback中的shouldDefer为YES 则是延迟创建订单（用户登陆中或者正在进行引导程序）稍后调用continuePayment方法继续下单。
 如果callback中的shouldCancel返回YES 则是取消订单， 表示APP 不支持通过App Store 发起支付流程
 
 @param productIdentifier 商品ID
 @param quantity 数量
 @param callback 回调程序
 */
- (void)userDidCreatePaymentWithProduct:(NSString *)productIdentifier andQuantity:(NSInteger)quantity completionCallback:(void (^)(NSDictionary *productInfo, BOOL shouldDefer, BOOL shouldCancel))callback;

@end


/**
 核心控制器：
 登入等出、切换绑定、登入新账号
 打开VC或视图
 购买
 appdelegate持有
 
 */
@interface ULManager : NSObject



/**
 初始化SDK 获取SDK核心管理类，需要将设置ULmanagerDelegate
 来接受各类回调方法

 @param gameID 游戏ID（必须）
 @param channel 渠道ID（必须）
 @return Manager对象
 */
+ (ULManager *) sharedManagerWithGameID:(NSString *)gameID
                              channelID:(NSString *)channel;




/**
 ULManager代理对象
 */
@property (weak, nonatomic) id <ULManagerDelegate> delegate;

#pragma mark - 实用工具


/**
 打印当前SDK的版本信息

 @return SDK版本字符串 例如 v1.1.1(100)
 */
+ (NSString *) version;

#pragma mark - 初始化逻辑

/**
 转发Facebook的启动逻辑

 @param application 传入application
 @param launchOptions 传入launchOptions
 @return 启动成功/失败
 */
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions;


/**
 转发Facebook的URL调起方法

 @param application 传入application
 @param url 传入url
 @param options 传入options
 @return 打开URL成功/失败
 */
- (BOOL)application:(UIApplication *)application openURL:(nonnull NSURL *)url options:(nonnull NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options;

- (BOOL) application:(UIApplication *)application continueUserActivity:(NSUserActivity *)userActivity restorationHandler:(void (^)(NSArray<id<UIUserActivityRestoring>> *restorableObjects))restorationHandler;

- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString*)sourceApplication annotation:(id)annotation;

- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken;

#pragma mark - 用户中心逻辑

/**
 展示用户中心页面，从用户中心按钮调用，遵循ULManagerDelegate来获取用户登入登出的回调

 @param viewController 调用该接口的ViewController
 @return 完成内部逻辑后直接返回YES
 */
- (BOOL)presentUserCenterfromViewController:(UIViewController *)viewController;

/**
 验证用户登录情况，如果用户没有登录会弹出对话框让用户输入登录信息

 @param viewController 传入本viewcontroller
 */
- (void)authenticateUserInViewController:(UIViewController *)viewController;


/**
 设置游戏角色信息 roleInfo对应的字段如下所示：
 游戏进入后台时、角色创建成功、切换角色成功时需要调用

 @param roleInfo 角色信息
 传入信息 字典 使用如下几个Key定义:
 #define kULCustomerVipLevel @"vip_Level" 
 #define kULRoleName @"playerName"
 #define kULServerName @"serverName"
 #define KULPlayerLevel @"roleLevel"
 #define kULGameVersionNumber @"gameVersion"
 #define kULServerId @"ulserverId"
 #define kULRoleId @"ulroleid"
*/
- (void)setRoleInfo:(NSDictionary *)roleInfo;


/**
 用户登出，状态通过userDidLogout回传
 */
- (void)logout;
  
#pragma mark - 支付逻辑


/**
 通过支付信息字典来帮助用户购买内购产品，需要在iTunes Connect上传相应的商品

 @param productInfo 产品信息字典
    包含的字段信息：
    uid 用户id
    orderid 订单号
    subject 商品名 string
    productid 商品id
    quantity 商品数量 int
    serverid 服务器id
    servername 服务器名称
    playername 角色名
    extinfo 备注
    price 价格 double
    subject 商品名
    roleId 角色ID
 */
- (void)makePaymentWithProductID:(NSDictionary *)productInfo;



/**
 继续之前延迟的订单，只适用于app store发起的支付

 @param orderID 传入订单号
 @return 订单创建成功则返回YES，单号不符或者创建失败返回NO
 */
- (BOOL)continuePaymentWithOrder:(NSString *)orderID;

/**
 开启谷歌登录方式，同时需要设置动态库的info.plist文件中的"Enable Third Party Channels-google"
 与Info.plist加入"GoogleClientID" ： "Your-Client-ID" 的方法互斥

 @param clientID 谷歌登录客户端ID
 */
- (void)enableGoogleSignInWithClientID:(NSString *)clientID;


- (void)openSendUserComplaintInViewController:(UIViewController *)viewController withRoleInfo:(NSDictionary *_Nullable)roleInfo;

@end

NS_ASSUME_NONNULL_END





